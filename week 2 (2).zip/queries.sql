-- Q1 Top 10 customers by total spend
SELECT customer_name, COUNT(*) AS num_orders, SUM(total_price) AS total_spent FROM orders GROUP BY customer_name ORDER BY total_spent DESC LIMIT 10;
-- Q2 Overall average order value
SELECT COUNT(*) AS total_orders, SUM(total_price) AS total_revenue, ROUND(AVG(total_price),2) AS avg_order_value FROM orders;
-- Q3 AOV by category
SELECT category, COUNT(*) AS orders, ROUND(AVG(total_price),2) AS avg_order_value, SUM(total_price) AS revenue FROM orders GROUP BY category ORDER BY avg_order_value DESC;
-- Q4 AOV by region
SELECT region, COUNT(*) AS orders, ROUND(AVG(total_price),2) AS avg_order_value, SUM(total_price) AS revenue FROM orders GROUP BY region ORDER BY avg_order_value DESC;
-- Q5 AOV by month
SELECT strftime('%Y-%m', order_date) AS month, COUNT(*) AS orders, ROUND(AVG(total_price),2) AS avg_order_value FROM orders GROUP BY month ORDER BY month;
-- Q6 Orders above average
SELECT customer_name, total_price FROM orders WHERE total_price > (SELECT AVG(total_price) FROM orders) ORDER BY total_price DESC;
-- Q7 Top customer per region
SELECT region, customer_name, total_price FROM (SELECT region, customer_name, total_price, RANK() OVER (PARTITION BY region ORDER BY total_price DESC) AS rnk FROM orders) t WHERE rnk=1 ORDER BY region;
